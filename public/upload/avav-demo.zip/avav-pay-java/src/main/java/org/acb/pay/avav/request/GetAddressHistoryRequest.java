package org.acb.pay.avav.request;

import lombok.Data;

@Data
public class GetAddressHistoryRequest {

  private String address;

  private long start = 0;

  private int limit = 100;

  private String ticker = "avav";

  /**
   * 额外返回的字段，多个用逗号分隔，如nonce
   */
  private String returnFields;

}
