package org.acb.pay.avav.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AddressHistoryItem {

  private Long id;

  private String tick;

  private String operation;

  private String from;

  private String to;

  private BigDecimal amount;

  private Integer valid;

  private String block;

  private String hash;

  private Long timestamp;

  private String nonce;
}
