package org.acb.pay.avav.request;

import lombok.Data;

@Data
public class CreateTransferUrlRequest {

  /**
   * 收款地址
   */
  private String address;

  /**
   * 要充值的对应USDT数量
   */
  private java.math.BigDecimal price;

  /**
   * 转账成功后跳回的url
   */
  private String returnUrl;

  /**
   * 对应铭文代码,默认avav
   */
  private String ticker = "avav";

  /**
   * 随机串，用于订单归因，可以传订单id
   */
  private String nonce;

}
