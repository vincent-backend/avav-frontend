package org.acb.pay.avav.model;

import lombok.Data;

@Data
public class OperationChainData {

  protected String p = "asc-20";

  protected String op;

  protected String tick = "avav";

  protected String amt;

  protected String nonce;
}
