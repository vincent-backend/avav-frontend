package org.acb.pay.utils;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

@Slf4j
@UtilityClass
public class HttpUtils {

  private OkHttpClient createHttpClient() {
    return new OkHttpClient.Builder()
            .connectTimeout(1, TimeUnit.MINUTES)
            .readTimeout(2, TimeUnit.MINUTES)
            .build();
  }

  public String get(String url, Map<String, String> headers) throws Exception {
    log.debug("start call url: {}", url);
    OkHttpClient client = createHttpClient();
    Request.Builder requestBuilder = createRequest(url, headers);
    Request request = requestBuilder
            .get()
            .build();
    Response response = client.newCall(request).execute();
    ResponseBody body = response.body();
    String result = body == null ? null : body.string();
    log.debug("finish call url: {} , response: {}", url, result);
    return result;
  }

  public String post(String url, String requestBodyStr, Map<String, String> headers) throws Exception {
    log.debug("start call url: {}", url);
    RequestBody requestBody = RequestBody.create(requestBodyStr, MediaType.parse("application/json"));
    OkHttpClient client = createHttpClient();
    Request.Builder requestBuilder = createRequest(url, headers);
    Request request = requestBuilder
            .post(requestBody)
            .build();
    Response response = client.newCall(request).execute();
    ResponseBody body = response.body();
    String result =  body == null ? null : body.string();
    log.debug("finish call url: {} , response: {}", url, result);
    return result;
  }

  private Request.Builder createRequest(String url, Map<String, String> headers) {
    Request.Builder builder = new Request.Builder().url(url);
    for (String key : headers.keySet()) {
      builder.addHeader(key, headers.get(key));
    }
    return builder;
  }
}
