package org.acb.pay.avav;

import org.acb.pay.avav.constants.Operation;
import org.acb.pay.avav.model.OperationChainData;
import org.acb.pay.avav.model.TickMarketInfo;
import org.acb.pay.avav.request.CreateTransferUrlRequest;
import org.acb.pay.avav.request.GetAddressHistoryRequest;
import org.acb.pay.avav.response.AddressHistoryResponse;
import org.acb.pay.avav.response.TickMarketInfoResponse;
import org.acb.pay.avav.response.TransactionInfoResponse;
import org.acb.pay.utils.HttpUtils;
import org.acb.pay.utils.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AvAvOpenApiClient {

  private static final String BASE_URL = "https://open-api.avascriptions.com";

  private String apiKey;

  public AvAvOpenApiClient(String apiKey) {
    this.apiKey = apiKey;
  }

  /**
   * 生成上链数据
   * @param price | 要充值的对应USDT数量
   * @param tick  | 对应铭文代码,如avav
   * @param nonce  | 随机串，用于订单归因，可以传订单id
   * @return string 16进制上链数据
   */
  public String makeChainData(BigDecimal price, String tick, String nonce) throws Exception {
    BigDecimal amount = getTickUSDAmount(price, tick);
    OperationChainData avAvOperationChainData = new OperationChainData();
    avAvOperationChainData.setAmt(amount.toString());
    avAvOperationChainData.setOp(Operation.TRANSFER);
    avAvOperationChainData.setTick(tick);
    avAvOperationChainData.setNonce(nonce);
    String json = JSONUtil.toJsonStr(avAvOperationChainData);
    json = String.format("data:,%s", json);
    log.info("chain data: {}", json);
    return StringUtils.decimalToHexString(json);
  }

  /**
   * 根据汇率转换成应收铭文数量
   * @param price  要充值的对应USDT数量
   * @param tick   对应铭文代码,如avav
   * @return
   * @throws Exception
   */
  public BigDecimal getTickUSDAmount(BigDecimal price, String tick) throws Exception {
    TickMarketInfoResponse tickMarketInfoResponse = getTickToUSDRate(tick);
    TickMarketInfo tickMarketInfo = tickMarketInfoResponse.getData();
    return price.divide(tickMarketInfo.getFloorPrice(), 0, RoundingMode.CEILING);
  }

  /**
   * 生成市场转账链接
   */
  public String makeTransferUrl(CreateTransferUrlRequest request) throws Exception {
    String tick = request.getTicker();
    String address = request.getAddress();
    BigDecimal amount = getTickUSDAmount(request.getPrice(), request.getTicker());
    String returnUrl = URLEncoder.encode(request.getReturnUrl(), "utf-8");
    String transferUrl = String.format("https://avascriptions.com/transfer?tick=%s&amount=%s&to=%s&return_url=%s&change=0", tick, amount, address, returnUrl);
    String nonce = request.getNonce();
    if (StringUtils.isNotEmpty(nonce)) {
      transferUrl = String.format("%s&additional=nonce:%s", transferUrl, nonce);
    }
    return transferUrl;
  }


  /**
   * 获取收款地址对应铭文的交易记录
   */
  public AddressHistoryResponse loadHistoryByAddress(GetAddressHistoryRequest request) throws Exception {
    String response = sendRequest("/v1/asc20/history-by-address", JSONUtil.toJsonStr(request));
    return JSONUtil.toBean(response, AddressHistoryResponse.class);
  }

  public TransactionInfoResponse getTransaction(String txId) throws Exception {
    Map<String, Object> params = new HashMap<>();
    params.put("txid", txId);
    String response = sendRequest("/v1/asc20/records-by-trxid", JSONUtil.toJsonStr(params));
    return JSONUtil.toBean(response, TransactionInfoResponse.class);
  }

  /**
   * 获取指定铭文汇率，若tick=avav，即avav/usdt的汇率
   */
  public TickMarketInfoResponse getTickToUSDRate(String tick) throws Exception {
    Map<String, String> params = new HashMap<>();
    params.put("ticker", tick);
    String response = sendRequest("/v1/market/info", JSONUtil.toJsonStr(params));
    return JSONUtil.toBean(response, TickMarketInfoResponse.class);
  }

  private String sendRequest(String url, String requestBody) throws Exception {
    String apiUrl = String.format("%s%s", BASE_URL, url);
    Map<String, String> headers = new HashMap<>();
    headers.put("Authorization", String.format("Bearer %s", apiKey));
    headers.put("Content-Type", "application/json");
    return HttpUtils.post(apiUrl, requestBody, headers);
  }

}
