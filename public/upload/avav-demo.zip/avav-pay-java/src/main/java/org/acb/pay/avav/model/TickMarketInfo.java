package org.acb.pay.avav.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class TickMarketInfo {

  private BigDecimal floorPrice;

  private String tick;

  private String number;

  private String holders;

  private String totalVolume;

  private String volumeDay;

  private String totalSales;

}
