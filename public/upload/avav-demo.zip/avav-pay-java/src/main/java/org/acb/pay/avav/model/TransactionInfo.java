package org.acb.pay.avav.model;

import lombok.Data;

@Data
public class TransactionInfo extends AddressHistoryItem {

}
