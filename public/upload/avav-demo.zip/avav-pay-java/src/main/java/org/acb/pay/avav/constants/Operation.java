package org.acb.pay.avav.constants;

public interface Operation {

  String TRANSFER = "transfer";
}
