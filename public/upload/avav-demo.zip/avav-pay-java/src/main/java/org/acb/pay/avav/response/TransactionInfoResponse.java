package org.acb.pay.avav.response;

import org.acb.pay.avav.model.TransactionInfo;

import java.util.List;

public class TransactionInfoResponse extends BaseResponse<List<TransactionInfo>> {
}
