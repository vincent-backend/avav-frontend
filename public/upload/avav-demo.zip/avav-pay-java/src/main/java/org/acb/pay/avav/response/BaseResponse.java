package org.acb.pay.avav.response;

import lombok.Data;

@Data
public class BaseResponse<T> {

  protected Integer status;

  protected T data;
}
