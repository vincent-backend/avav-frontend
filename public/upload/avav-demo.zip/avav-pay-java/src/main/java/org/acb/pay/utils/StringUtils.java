package org.acb.pay.utils;

import javax.xml.bind.DatatypeConverter;

public class StringUtils extends org.apache.commons.lang3.StringUtils {

  public static String decimalToHexString(String decimalStr) {
    StringBuilder hexStr = new StringBuilder();
    char[] charArray = decimalStr.toCharArray();
    for (char c : charArray) {
      String charToHex = Integer.toHexString(c);
      hexStr.append(charToHex);
    }
    return hexStr.toString();
  }

  public static String hexToDecimalString(String hexStr) {
    byte[] bytes = DatatypeConverter.parseHexBinary(hexStr);
    return new String(bytes);
  }

  public static void main(String[] args) {
    String str = "646174613a2c7b2270223a226173632d3230222c226f70223a227472616e73666572222c227469636b223a2261766176222c22616d74223a223535363839323432227d";
    String ret = hexToDecimalString(str);
    System.out.println(ret);
  }
}
