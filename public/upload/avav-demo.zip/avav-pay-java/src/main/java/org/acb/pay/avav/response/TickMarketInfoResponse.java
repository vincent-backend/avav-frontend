package org.acb.pay.avav.response;

import org.acb.pay.avav.model.TickMarketInfo;

public class TickMarketInfoResponse extends BaseResponse<TickMarketInfo> {
}
