package org.acb.pay.avav.response;

import org.acb.pay.avav.model.AddressHistoryItem;

import java.util.List;

public class AddressHistoryResponse extends BaseResponse<List<AddressHistoryItem>> {
}
