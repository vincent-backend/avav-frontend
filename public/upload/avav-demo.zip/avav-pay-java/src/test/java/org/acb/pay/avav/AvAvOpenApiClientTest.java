package org.acb.pay.avav;

import org.acb.pay.avav.model.AddressHistoryItem;
import org.acb.pay.avav.request.CreateTransferUrlRequest;
import org.acb.pay.avav.request.GetAddressHistoryRequest;
import org.acb.pay.avav.response.AddressHistoryResponse;
import org.acb.pay.avav.response.TickMarketInfoResponse;
import org.acb.pay.avav.response.TransactionInfoResponse;

import java.math.BigDecimal;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.json.JSONUtil;

public class AvAvOpenApiClientTest {

  public static AvAvOpenApiClient createClient() {
    return new AvAvOpenApiClient("fSvL3CHWG3sNsZkMQPXp3x6DT1Mscc97");
  }

  public static void testGetTickToUSDRate() throws Exception {
    AvAvOpenApiClient client = createClient();
    TickMarketInfoResponse tickMarketInfo = client.getTickToUSDRate("avav");
    System.out.println(tickMarketInfo);
  }

  public static void testMakeChainData() throws Exception {
    AvAvOpenApiClient client = createClient();
    String chainData = client.makeChainData(BigDecimal.ONE, "avav", RandomUtil.randomNumbers(10));
    System.out.println(chainData);
  }

  public static void testGetAddressHistory() throws Exception {
    AvAvOpenApiClient client = createClient();
    GetAddressHistoryRequest request = new GetAddressHistoryRequest();
//    request.setAddress("0x2690a19f560ba9721dc78dc02a978266468cc7da");
    request.setAddress("0x926EFb0cF2c554Dd8A02D68c799421Cd36559C27");
    request.setReturnFields("nonce");
    AddressHistoryResponse response = client.loadHistoryByAddress(request);
    if (response.getData() != null) {
      for (AddressHistoryItem item : response.getData()) {
        String nonce = item.getNonce();
        //TODO 根据下单时传入的nonce进行订单归因，例如nonce表示订单id，则根据订单id查找订单并修改订单状态
      }
    }
    System.out.println(response);
  }

  public static void testGetTransaction() throws Exception {
    AvAvOpenApiClient client = createClient();
    TransactionInfoResponse response = client.getTransaction("0x4531b6c1dfabc56e92f34a37ae735648a90d7d88f1cc6e38b37b38e2ce2edefe");
    System.out.println(JSONUtil.toJsonStr(response));
  }

  public static void testMakeTransferUrl() throws Exception {
    AvAvOpenApiClient client = createClient();
    CreateTransferUrlRequest request = new CreateTransferUrlRequest();
    request.setAddress("0x926EFb0cF2c554Dd8A02D68c799421Cd36559C27");
    request.setNonce(RandomUtil.randomString(10));//可以传订单id，扫描交易记录可以拿到这个信息，从而可以归因到支付对应的订单
    request.setReturnUrl("http://host");//支付后跳转的url
    request.setPrice(BigDecimal.ONE);
    String url = client.makeTransferUrl(request);
    System.out.println(url);
  }

  public static void main(String[] args) throws Exception {
//    //测试获取指定铭文兑换USDT的汇率
//    testGetTickToUSDRate();
//    //测试构造上链数据
//    testMakeChainData();

    //测试生成转账url，这个连接在钱包浏览器打开即可跳转AVAV并引导用户支付
    testMakeTransferUrl();

    //测试获取指定钱包的历史交易记录，
    testGetAddressHistory();
  }
}
