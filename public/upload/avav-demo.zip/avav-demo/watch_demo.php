<?php
/**
 * 钱包监控简单示例，切勿直接用于生产环境
 * 钱包监控简单示例，切勿直接用于生产环境
 * 钱包监控简单示例，切勿直接用于生产环境
 * 钱包监控简单示例，切勿直接用于生产环境
 * 钱包监控简单示例，切勿直接用于生产环境
 *
 *
 *
 *
 * 实际业务场景可以用队列、定时任务等来实现
 * 这里随便写个死循环用于简单示例
 */


require 'AvavService/AvavService.php';


$api_key = "xxxxxxxx";
$avavService = new AvavService($api_key);
$address = "x1x1x1x1xx1x1x1x1x1x1x1";//需要监控的地址
while (1==1){
    $now = time();

    //初始化偏移，初始是0就是不偏移，查询该地址的所有记录
    $last_offset = 0;


    $history_list = $list = $avavService->loadHistoryByAddress($last_offset);

    //首次读取需要读取完整的交易列表，以防漏掉数据
    while (count($history_list) >= 50) {
        //创建临时偏移，实际是类似翻页的功能，只是这个偏移需要的是交易记录的id
        $offset = $history_list[count($history_list) - 1]['id'];

        $history_list = $avavService->loadHistoryByAddress($address,$offset);
        $list = array_merge($list, $history_list);
    }


    //需要维护所有已经到账订单对应的history记录的ID，避免重复处理
    $used_ids = [];
    foreach ($list as $item) {
        if (time() - $item['timestamp'] > (30 * 60) && $item['id'] > $last_offset) {
             //三十分钟之前的数据可以跳过，每单锁三十分钟
             //就是保存偏移id，下次就用这个偏移id来读取三十分钟内的数据
           $last_offset = $item['id'];
        }


        //TODO 如果对应的id已经处理过了，则跳过，避免重复到账，此处简单示例，根据自己业务逻辑来做
        if (in_array($item['id'], $used_ids)) {
            continue;
        }


        //只处理三十分钟内的订单
        if(time() - $item['timestamp'] > 1800){


            //TODO 这里根据金额来匹配对应的订单，并且处理订单到账
            $order_id = "根据金额反查订单";
            if(!$order_id){
                continue;
            }else{
                //TODO 处理到账，入库，把$item['id']设置为已处理
                echo "ID:" . $item['id'] . "的记录已经到账";
                $used_ids[] = $item['id'];
                echo "<br/>";
                echo "<br/>";
            }


        }

    }

    sleep(5);
}
