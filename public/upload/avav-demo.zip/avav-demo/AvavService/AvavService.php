<?php
require __DIR__.'/../vendor/autoload.php';
/**
 * api文档
 * https://docs.avascriptions.com/
 */

class AvavService{
    protected $base_url = "https://open-api.avascriptions.com";

    /**
     * 这里填写自己的APIKEY
     */
    protected $api_key;

    public function __construct($api_key)
    {
        $this->api_key = $api_key;
    }

    /**
     * @param $price | 要充值的对应USDT数量
     * @param $tick | 对应铭文代码,默认avav
     * @return string 16进制上链数据
     */
    public function makeChainData($price,$tick = "avav"){
        //price是要充值的对应USDT数量
        //根据汇率转换成应收铭文数量
        $amount = $price / $this->getTickToUSDRate();

        //TODO 这里可以酌情增加金额唯一逻辑，每个金额锁定三十分钟，用于绑定订单

        $chain_data = [
            'p' => 'asc-20',
            'op' => 'transfer',
            'tick' => $tick,
            'amt' => $amount,
        ];
        $chain_data = json_encode($chain_data);
        $chain_data = "data:,".$chain_data;
        return bin2hex($chain_data);
    }


    /**
     * @param $price | 要充值的对应USDT数量
     * @param $return_url | 转账成功后跳回的url
     * @param $tick | 对应铭文代码,默认avav
     * @return string 市场转账链接
     */
    public function makeTransferUrl($address,$price, $return_url,$tick='avav'){
        //price是要充值的对应USDT数量
        //根据汇率转换成应收铭文数量
        $amount = $price / $this->getTickToUSDRate();

        //TODO 这里可以酌情增加金额唯一逻辑，每个金额锁定三十分钟，用于绑定订单


        $return_url = urlencode($return_url);

        $transfer_url = "https://avascriptions.com/transfer?tick={$tick}&amount={$amount}&to={$address}&return_url={$return_url}&change=0";
        return $transfer_url;
    }


    /**
     * 监听收款地址->对应铭文的交易记录
     */
    public function loadHistoryByAddress($address,$offset_id = 0, $limit = 50,$tick='avav')
    {
        $uri = "/v1/asc20/history-by-address";
        $data = [
            'address' => $address,
            'start' => $offset_id,
            'limit' => $limit,
            'operation' => 'transfer',
            'ticker' => $tick,
        ];
        $list = $this->sendRequest($uri, $data);
        return $list['data'];
    }


    /**
     * 获取指定铭文汇率，默认avav
     */
    private function getTickToUSDRate($tick = "avav")
    {
        $uri = '/v1/market/info';
        $data = [
            'ticker' => $tick
        ];
        $result = $this->sendRequest($uri, $data);
        $rate = $result['data']['floorPrice'];
        //获取到的是avav/usdt的汇率
        return $rate;
    }



    /**
     * 发送请求
     */
    public function sendRequest($uri,$data,$method="POST"){
        $client = new \GuzzleHttp\Client();
        $headers = [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        ];
        try {
            if ($method == "POST") {
                $request = $client->post($this->base_url . $uri, [
                    'json' => $data,
                    'headers' => $headers,
                ]);
            } else {
                $url = $this->base_url.$uri."?".http_build_query($data);
                $request = $client->get($url,['headers'=>$headers]);
            }
            $response = $request->getBody()->getContents();
            $response = json_decode($response, true);
            if ($response['status'] != 200) {
                throw new \Exception('请求失败', 400);
            }
            return $response;

        } catch (\GuzzleHttp\Exception\GuzzleException $e) {
            throw new \Exception($e->getMessage(), 400);
        }
    }
}
