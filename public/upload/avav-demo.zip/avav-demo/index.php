<?php
/**
 * 无dapp无签名AVAV支付示例
 * 简单AVAV支付示例，用到的包可以自己酌情修改
 * Guzzle:请求接口，Qrcode:生成二维码
 * 该demo只实现简单的交互逻辑，实际业务逻辑还需自己整合。
 * avav主要就是靠上链数据触发合约来完成转账，根据官方给到的接口可以实现余额监控、到账监控等需求，这里会略过余额监控，根据自己的业务流程，如果能前置获知用户转账地址建议先做余额判定。
 * 钱包到账监控见watch_demo.php
 *
 ******* 上链数据需要在转账的时候粘贴的高级功能内的16进制上链数据，该功能一般常用的钱包都会有的，但是经过实测，欧易推出的web3钱包是没有高级功能的。*******
 ******* 其他交易所的web3钱包需要自己测试 ******
 */
require 'AvavService/AvavService.php';


$api_key = "xxxxxxxx";
$avavService = new AvavService($api_key);

//收款地址
$address = "xxxxxxxxxxxxxxxxxxx";

$usdt_price = 100;


//生成上链数据，引导用户直接使用钱包转账，avax填写0，然后直接复制上链数据到钱包转账界面的的高级功能内的16进制.
$chain_data = $avavService->makeChainData($usdt_price);

echo "======================================<br/>";
echo "无DApp,无签名AVAV支付流程";
echo "<br/>";
echo "收款地址: " . $address;
echo "<br/>";
echo "转账铭文价值(USDT): " . $price;
echo "<br/>";
echo "上链数据: ".$chain_data;
echo "<br/>";
echo "======================================";
echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";




//生成官方市场转账链接，用户只需要授权即可转账，流程缩短了一半。
$transfer_url = $avavService->makeTransferUrl($address, $usdt_price,"https://www.google.com/");
echo "======================================<br/>";
echo "官方市场转账流程";
echo "<br/>";
echo "收款地址: " . $address;
echo "<br/>";
echo "转账铭文价值(USDT): " . $price;
echo "<br/>";
echo "专属转账链接: <a href='".$transfer_url."' target='_blank'>" . $transfer_url."</a>";
echo "<br/>";
echo "======================================";
echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";
