<?php
/**
 * 市场api文档
 * https://docs.avascriptions.com/
 */

namespace Helloworld\AvavTransfer;


class Transfer{
    protected $base_url = "https://open-api.avascriptions.com";

    /**
     * 这里填写自己的APIKEY
     */
    protected $api_key;

    public function __construct($api_key)
    {
        $this->api_key = $api_key;
    }

    /**
     * @param $price | 要充值的对应USDT数量
     * @param $outTradeNo | 订单ID，用于监控钱包时归因订单
     * @param $tick | 对应铭文代码,默认avav
     * @return string 16进制上链数据
     */
    public function makeChainData($price, $outTradeNo,$tick = "avav"){
        //price是要充值的对应USDT数量
        //根据汇率转换成应收铭文数量
        $amount = $price / $this->getTickToUSDRate();


        $chain_data = [
            'p' => 'asc-20',
            'op' => 'transfer',
            'tick' => $tick,
            'amt' => $amount,
            'outTradeNo' => $outTradeNo,
        ];
        $chain_data = json_encode($chain_data);
        $chain_data = "data:,".$chain_data;
        return bin2hex($chain_data);
    }


    /**
     * @param $address | 收款钱包地址
     * @param $price | 要充值的对应USDT数量
     * @param $return_url | 转账成功后跳回的url
     * @param $outTradeNo | 订单ID，用于监控钱包时归因订单
     * @param $tick | 对应铭文代码,默认avav
     * @return string 市场转账链接
     */
    public function makeTransferUrl($address,$price, $return_url, $outTradeNo,$tick='avav'){
        //price是要充值的对应USDT数量
        //根据汇率转换成应收铭文数量
        $amount = $price / $this->getTickToUSDRate();


        $return_url = urlencode($return_url);

        $transfer_url = "https://avascriptions.com/transfer?tick={$tick}&amount={$amount}&to={$address}&return_url={$return_url}&additional=outTradeNo:{$outTradeNo}&change=0";
        return $transfer_url;
    }


    /**
     * 监听收款地址->对应铭文的交易记录
     * @param $address | 监控钱包地址
     * @param $offset_id | 偏移ID，0为不偏移  Ps:这里的ID是接口返回的ID
     * @param $limit | 单次查询记录数量
     * @param $tick | 要监控的铭文代码,默认avav
     */
    public function loadHistoryByAddress($address,$offset_id = 0, $limit = 50,$tick='avav')
    {
        $uri = "/v1/asc20/history-by-address";
        $data = [
            'address' => $address,
            'start' => $offset_id,
            'limit' => $limit,
            'operation' => 'transfer',
            'ticker' => $tick,
            'returnFields'  => 'outTradeNo'
        ];
        $list = $this->sendRequest($uri, $data);
        return $list['data'];
    }


    /**
     * 获取指定铭文汇率，默认avav
     */
    private function getTickToUSDRate($tick = "avav")
    {
        $uri = '/v1/market/info';
        $data = [
            'ticker' => $tick
        ];
        $result = $this->sendRequest($uri, $data);
        $rate = $result['data']['floorPrice'];
        //获取到的是avav/usdt的汇率
        return $rate;
    }



    /**
     * 发送请求
     */
    public function sendRequest($uri,$data,$method="POST"){
        // 初始化 cURL 会话
        $curl = curl_init();

        // 设置要 POST 的 URL
        $url = $this->base_url;

        // 设置 POST 数据及编码为 JSON
        $jsonData = json_encode($data);

        // 设置自定义请求头，包括认证令牌和表示发送 JSON 内容类型的请求头
        $customHeaders = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );

        // 设置 cURL 选项
        curl_setopt($curl, CURLOPT_URL, $url.$uri); // 要访问的 URL
        curl_setopt($curl, CURLOPT_POST, true); // 请求方式为 POST
        curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonData); // JSON 数据
        curl_setopt($curl, CURLOPT_HTTPHEADER, $customHeaders); // 自定义请求头

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); // 将 curl_exec() 获取的信息以文件流的形式返回，而不是直接输出
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 若请求 HTTPS 地址，禁止 cURL 验证对等证书

        // 执行 cURL 请求
        $response = curl_exec($curl);

        // 检查是否有错误发生
        if (curl_errno($curl)) {
            throw new \Exception(curl_error($curl), 500);
        }

        // 关闭 cURL 会话
        curl_close($curl);


        $response = json_decode($response, true);
        if ($response['status'] != 200) {
            throw new \Exception('请求失败', 400);
        }
        return $response;
    }
}
