### 无Dapp/无签名 --- AVAV铭文支付SDK
---
### apikey需要向官方市场发邮件申请
---
##### 根据实际测试，avav链上确认速度非常快，平均到账速度在15秒左右，有时候更快可以达到5秒内到账，avav转账无损耗并且只需要微量的gas fee


```
------ 2024-01-30新增 ------
市场接口升级，允许监控上链数据
升级监控机制，通过上链数据来归因订单。


------ 2024-01-23新增 ------
index.php 新增生成市场转账链接的示例，可以根据自己的应用的业务逻辑酌情使用。
市场转账天然能获得用户的信任度，并且流程比手动转账更简便。

```
---
### 生成订单示例

v2版-利用官方市场转账，流程相对简单，并且可以有效降低误操作。
```php
use Helloworld\AvavTransfer\Transfer;

$api_key = "xxxxxxxx";
$transferService = new Transfer($api_key);

//收款地址
$address = "xxxxxxxxxxxxxxxxxxx";

//本示例采用usdt为本币种，传入方法后会根据USDT -> avav 汇率来计算、生成出应付的avav数量。
$usdt_price = 100;

//这里应该是你自己的订单ID
$out_trade_no = 1;

//生成官方市场转账链接，用户只需要授权即可转账，流程比V1更顺畅。
$transfer_url = $transferService->makeTransferUrl($address, $usdt_price,$out_trade_no,"https://www.google.com/");
echo "======================================<br/>";
echo "官方市场转账<br/>";
echo "收款地址: " . $address."<br/>";
echo "转账铭文价值(USDT): " . $price."<br/>";
echo "OutTradeNo: " . $out_trade_no."<br/>";
echo "专属转账链接: <a href='".$transfer_url."' target='_blank'>" . $transfer_url."</a><br/>";
echo "======================================";
```


v1版-生成上链数据，引导用户复制数据并通过钱包转账:
```php
use Helloworld\AvavTransfer\Transfer;

$api_key = "xxxxxxxx";
$transferService = new Transfer($api_key);

//收款地址
$address = "xxxxxxxxxxxxxxxxxxx";

//本示例采用usdt为本币种，传入方法后会根据USDT -> avav 汇率来计算、生成出应付的avav数量。
$usdt_price = 100;

//这里应该是你自己的订单ID
$out_trade_no = 1;

//生成上链数据，引导用户直接使用钱包转账，avax填写0，然后直接复制上链数据到钱包转账界面的的高级功能内的16进制.
$chain_data = $transferService->makeChainData($usdt_price,$out_trade_no);

echo "======================================<br/>";
echo "无DApp,无签名AVAV支付示例<br/>";
echo "收款地址: " . $address."<br/>";
echo "转账铭文价值(USDT): " . $price."<br/>";
echo "OutTradeNo: " . $out_trade_no."<br/>";
echo "上链数据: ".$chain_data."<br/>";
echo "======================================";
```

---
### 订单监控示例

```php
use Helloworld\AvavTransfer\Transfer;

$api_key = "xxxxxxxx";
$transferService = new Transfer($api_key);
$address = "x1x1x1x1xx1x1x1x1x1x1x1";//需要监控的地址
while (1==1){
    $now = time();

    //初始化偏移，初始是0就是不偏移，查询该地址的所有记录
    $last_offset = 0;

    $history_list = $list =  $transferService->loadHistoryByAddress($last_offset);

    //首次读取需要读取完整的交易列表，以防漏掉数据
    while (count($history_list) >= 50) {
        //创建临时偏移，实际是类似翻页的功能，只是这个偏移需要的是交易记录的id
        $offset = $history_list[count($history_list) - 1]['id'];

        $history_list = $transferService->loadHistoryByAddress($address,$offset);
        $list = array_merge($list, $history_list);
    }

    //订单监控时效，这里代表分钟数
    $effective_time = 30;

    $effective_time = $effective_time * 60;

    //需要维护所有已经到账订单对应的history记录的ID，避免重复处理
    $used_ids = [];
    foreach ($list as $item) {
        if (time() - $item['timestamp'] > $effective_time && $item['id'] > $last_offset) {
             //订单监控时效之前的数据可以跳过，本示例每条交易记录的时效为三十分钟
             //就是保存偏移id，下次就用这个偏移id来读取订单监控时效内的数据
           $last_offset = $item['id'];
        }


        //TODO 如果对应的id已经处理过了，则跳过，避免重复到账，此处简单示例，根据自己业务逻辑来做
        if (in_array($item['id'], $used_ids)) {
            continue;
        }

        //只处理监控时效内的订单
        if(time() - $item['timestamp'] > $effective_time){

            $order_id = $item['outTradeNo'];
            if(!$order_id){
                continue;
            }else{
                //TODO 处理到账，入库，把$item['id']设置为已处理
                echo "ID:" . $item['id'] . "的记录已经到账";
                $used_ids[] = $item['id'];
            }
        }
    }
    sleep(5);
}
```
